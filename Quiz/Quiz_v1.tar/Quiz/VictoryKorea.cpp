#include <stdlib.h>
#include <string.h>

class CharacterShifting
{
	public:
		CharacterShifting();
		~CharacterShifting();

	private:

};
