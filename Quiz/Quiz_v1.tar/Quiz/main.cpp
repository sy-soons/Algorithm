
#include <iostream>
#include <string>
#include <fstream>
using namespace std;

#define TOTAL_ALPHABET 27//26
#define HEIGHT_ALPHABET 7
#define WIDTH_ALPHABET 6
#define SCALE_RATE_HEIGHT 6
#define SCALE_RATE_WIDTH 2
#define SCALED_HEIGTH_ALPHABET SCALE_RATE_HEIGHT*HEIGHT_ALPHABET
#define SCALED_WIDTH_ALPHABET SCALE_RATE_WIDTH*WIDTH_ALPHABET

char chAlphabet[26][7][7] = {
	{
		"011110",
		"110011",
		"110011",
		"111111",
		"110011",
		"110011",
		"110011"
	},
	{
		"111110",
		"110011",
		"110011",
		"111110",
		"110011",
		"110011",
		"111110"
	},
	{
		"011110",
		"110011",
		"110000",
		"110000",
		"110000",
		"110011",
		"011110",
	},
	{
		"111110",
		"110011",
		"110011",
		"110011",
		"110011",
		"110011",
		"111110",
	},
	{
		"011111",
		"110000",
		"110000",
		"111110",
		"110000",
		"110000",
		"011111",
	},
	{
		"111111",
		"110000",
		"110000",
		"111110",
		"110000",
		"110000",
		"110000",
	},
	{
		"011110",
		"110011",
		"110000",
		"110111",
		"110011",
		"110011",
		"011110",
	},
	{
		"110011",
		"110011",
		"110011",
		"111111",
		"110011",
		"110011",
		"110011",
	},
	{
		"011110",
		"001100",
		"001100",
		"001100",
		"001100",
		"001100",
		"011110",
	},
	{
		"000110",
		"000110",
		"000110",
		"000110",
		"000110",
		"110110",
		"011100",
	},
	{
		"110011",
		"110110",
		"111100",
		"111000",
		"111100",
		"110110",
		"110011",
	},
	{
		"110000",
		"110000",
		"110000",
		"110000",
		"110000",
		"110000",
		"111111",
	},
	{
		"110011",
		"111111",
		"111111",
		"110011",
		"110011",
		"110011",
		"110011",
	},
	{
		"110011",
		"110011",
		"111011",
		"110111",
		"110011",
		"110011",
		"110011",
	},
	{
		"011110",
		"110011",
		"110011",
		"110011",
		"110011",
		"110011",
		"011110",
	},
	{
		"111110",
		"110011",
		"110011",
		"111110",
		"110000",
		"110000",
		"110000",
	},
	{
		"011110",
		"110011",
		"110011",
		"110011",
		"110111",
		"011110",
		"000011",
	},
	{
		"111110",
		"110011",
		"110011",
		"111110",
		"111100",
		"110110",
		"110011",
	},
	{
		"011110",
		"110011",
		"110000",
		"011110",
		"000011",
		"110011",
		"011110",
	},
	{
		"111111",
		"001100",
		"001100",
		"001100",
		"001100",
		"001100",
		"001100",
	},
	{
		"110011",
		"110011",
		"110011",
		"110011",
		"110011",
		"110011",
		"011110",
	},
	{
		"110011",
		"110011",
		"110011",
		"110011",
		"110011",
		"011110",
		"001100",
	},
	{
		"110011",
		"110011",
		"110011",
		"110011",
		"111111",
		"111111",
		"110011",
	},
	{
		"110011",
		"110011",
		"011110",
		"001100",
		"011110",
		"110011",
		"110011",
	},
	{
		"110011",
		"110011",
		"110011",
		"011110",
		"001100",
		"001100",
		"001100",
	},
	{
		"111111",
		"000011",
		"000110",
		"001100",
		"011000",
		"110000",
		"111111",
	},

};

std::string strAlphabet[TOTAL_ALPHABET][HEIGHT_ALPHABET] = {
	{
		"011110",
		"110011",
		"110011",
		"111111",
		"110011",
		"110011",
		"110011"
	},
	{
		"111110",
		"110011",
		"110011",
		"111110",
		"110011",
		"110011",
		"111110"
	},
	{
		"011110",
		"110011",
		"110000",
		"110000",
		"110000",
		"110011",
		"011110",
	},
	{
		"111110",
		"110011",
		"110011",
		"110011",
		"110011",
		"110011",
		"111110",
	},
	{
		"011111",
		"110000",
		"110000",
		"111110",
		"110000",
		"110000",
		"011111",
	},
	{
		"111111",
		"110000",
		"110000",
		"111110",
		"110000",
		"110000",
		"110000",
	},
	{
		"011110",
		"110011",
		"110000",
		"110111",
		"110011",
		"110011",
		"011110",
	},
	{
		"110011",
		"110011",
		"110011",
		"111111",
		"110011",
		"110011",
		"110011",
	},
	{
		"011110",
		"001100",
		"001100",
		"001100",
		"001100",
		"001100",
		"011110",
	},
	{
		"000110",
		"000110",
		"000110",
		"000110",
		"000110",
		"110110",
		"011100",
	},
	{
		"110011",
		"110110",
		"111100",
		"111000",
		"111100",
		"110110",
		"110011",
	},
	{
		"110000",
		"110000",
		"110000",
		"110000",
		"110000",
		"110000",
		"111111",
	},
	{
		"110011",
		"111111",
		"111111",
		"110011",
		"110011",
		"110011",
		"110011",
	},
	{
		"110011",
		"110011",
		"111011",
		"110111",
		"110011",
		"110011",
		"110011",
	},
	{
		"011110",
		"110011",
		"110011",
		"110011",
		"110011",
		"110011",
		"011110",
	},
	{
		"111110",
		"110011",
		"110011",
		"111110",
		"110000",
		"110000",
		"110000",
	},
	{
		"011110",
		"110011",
		"110011",
		"110011",
		"110111",
		"011110",
		"000011",
	},
	{
		"111110",
		"110011",
		"110011",
		"111110",
		"111100",
		"110110",
		"110011",
	},
	{
		"011110",
		"110011",
		"110000",
		"011110",
		"000011",
		"110011",
		"011110",
	},
	{
		"111111",
		"001100",
		"001100",
		"001100",
		"001100",
		"001100",
		"001100",
	},
	{
		"110011",
		"110011",
		"110011",
		"110011",
		"110011",
		"110011",
		"011110",
	},
	{
		"110011",
		"110011",
		"110011",
		"110011",
		"110011",
		"011110",
		"001100",
	},
	{
		"110011",
		"110011",
		"110011",
		"110011",
		"111111",
		"111111",
		"110011",
	},
	{
		"110011",
		"110011",
		"011110",
		"001100",
		"011110",
		"110011",
		"110011",
	},
	{
		"110011",
		"110011",
		"110011",
		"011110",
		"001100",
		"001100",
		"001100",
	},
	{
		"111111",
		"000011",
		"000110",
		"001100",
		"011000",
		"110000",
		"111111",
	},
	{
		"000000",
		"000000",
		"000000",
		"000000",
		"000000",
		"000000",
		"000000",
	},
};

std::string scaledStrAlphabet[TOTAL_ALPHABET][SCALED_HEIGTH_ALPHABET];

std::string replaceAll(std::string &str, const std::string& from, const std::string& to)
{
    size_t start_pos = 0; //string처음부터 검사
    while((start_pos = str.find(from, start_pos)) != std::string::npos)  //from을 찾을 수 없을 때까지
    {
        str.replace(start_pos, from.length(), to);
        start_pos += to.length(); // 중복검사를 피하고 from.length() > to.length()인 경우를 위해서
    }
    return str;
}


void replaceAlphabetCharacter()
{
	for (int i = 0; i < TOTAL_ALPHABET; i++)
	{
		// std::string strCur = replaceAll(strAlphabet[j][i], "1", "@");
		for (int j = 0; j < HEIGHT_ALPHABET; j++) 
		{
			strAlphabet[i][j] = replaceAll(strAlphabet[i][j], "1", "@");
			// cout << strAlphabet[i][0] << endl;
		}
	}	
}

void setScaledAlphabet()
{
	std::string curStr[TOTAL_ALPHABET][HEIGHT_ALPHABET];
	for (int i = 0; i < TOTAL_ALPHABET; i++)
	{

		// cout << "===============> scaling width result"<<endl;

		//가로 확대
		for (int j = 0; j < HEIGHT_ALPHABET; j++)
		{
			// scaledStrAlphabet[i][j] = replaceAll(strAlphabet[i][j], "0", "00");
			// scaledStrAlphabet[i][j] = replaceAll(strAlphabet[i][j], "@", "@@");
			curStr[i][j] = replaceAll(strAlphabet[i][j], "0", "  ");
			curStr[i][j] = replaceAll(strAlphabet[i][j], "@", "@@");
			// cout << curStr[i][j] << endl;
		}
		// cout << "===============>"<<endl;


		//세로 확대(x6) -> 한 행을 6번 쓰기
		// int curIdx = 0;
		// cout << "scaled rate: " << SCALE_RATE_HEIGHT <<endl;
		// cout << "scaled height : " << SCALED_HEIGTH_ALPHABET <<endl;

		for (int curIdx = 0; curIdx < SCALED_HEIGTH_ALPHABET; curIdx+=SCALE_RATE_HEIGHT)
		{
			std::string strTemp = curStr[i][curIdx/SCALE_RATE_HEIGHT];
			for (int k = 0; k < SCALE_RATE_HEIGHT; k++)
			{
				scaledStrAlphabet[i][curIdx+k] = strTemp;
				// cout << scaledStrAlphabet[i][curIdx+k]<<endl;
			}
		}
	}
}

void printHorizontalAlphabet()
{
	int nPrintCharacters = 5;
	for (int i = 0; i < HEIGHT_ALPHABET; i++)
	{
		for (int j = 0; j < nPrintCharacters; j++) 
		{
			cout << strAlphabet[j][i];
			cout << " ";
		}
		cout << endl;
	}
}

void printHorizontalScaledAlphabet()
{
	int nPrintCharacters = 5;
	for (int i = 0; i < SCALED_HEIGTH_ALPHABET; i++)
	{
		for (int j = 0; j < nPrintCharacters; j++) 
		{
			cout << scaledStrAlphabet[j][i];
			cout << " ";
		}
		cout << endl;
	}
}
ofstream ofile;
void printVerticalScaledAlphabet(int idxAlphabet)
{

	// cout << "vertical ~~~" <<endl;
	// std::string curAlphabet[HEIGHT_ALPHABET];
	// curAlphabet = scaledStrAlphabet[idxAlphabet];

	// std::string currentStr = scaledStrAlphabet[idxAlphabet][0];
	// cout << currentStr << endl;
	// cout << currentStr[0] << endl;
	// cout << currentStr[1] << endl;
	// cout << currentStr[2] << endl;
	// cout << currentStr[3] << endl;

	// currentStr = scaledStrAlphabet[idxAlphabet][6];
	// cout << currentStr[0] << endl;

	for (int i = 0; i < SCALED_WIDTH_ALPHABET; i++)
	// for (int i = SCALED_WIDTH_ALPHABET; i >= 0; i--)
	{
		// for (int k = 0; k < SCALED_HEIGTH_ALPHABET; k++) 
		for (int k = SCALED_HEIGTH_ALPHABET-1; k >= 0; k--)
		{
			std::string currentStr = scaledStrAlphabet[idxAlphabet][k];
			cout << currentStr[i];
			ofile << currentStr[i];
		}
		ofile << endl;
		cout << endl;
	}

}
void printOneVerticalWord()
{

}

int getAlphabetIdx(char ch)
{
	int errVal = -1;

	if (ch >= 0x61) 
	{
		return ch - 0x61;
	}
	else if (ch >= 0x41)
	{
		return ch - 0x41;
	}
	else if (ch == ' ')
	{
		return TOTAL_ALPHABET-1;
	}
	else 
	{
		cout << "invalid character: " << ch << endl;
		return -1;
	}
return errVal;
}

int main()
{
	cout << "main" <<endl;

	// "1"을 "@"로 바꾸기
	cout << "converting ======" << endl;
	replaceAlphabetCharacter();


	int nPrintCharacters = 5;
	//가로로 출력하기
	// cout << "horizontal print ~~" << endl;
	// cout << "========================" << endl;
	// int nPrintCharacters = 5;
	// for (int i = 0; i < HEIGHT_ALPHABET; i++)
	// {
	// 	for (int j = 0; j < nPrintCharacters; j++) 
	// 	{
	// 		cout << strAlphabet[j][i];
	// 		cout << " ";
	// 	}
	// 	cout << endl;
	// }

	// cout << "scaled Alphabet string ~~~~" <<endl;
	// cout << "========================" << endl;
	setScaledAlphabet();
	// for (int i = 0; i < SCALED_HEIGTH_ALPHABET; i++)
	// {
	// 	for (int j = 0; j < nPrintCharacters; j++) 
	// 	{
	// 		cout << scaledStrAlphabet[j][i];
	// 		cout << " ";
	// 	}
	// 	cout << endl;
	// }

	char inBuffer[500];
	cout << "input the word: " <<endl;
	cin.getline(inBuffer, 500);
	cout << "typed word: " << inBuffer <<endl;

	std::string strWord(inBuffer);
	// cout << "in string: "<<strWord<<endl;

	// cout << "Alphabet index : " << getAlphabetIdx(strWord[0]) << ", character: " << strWord[0]<<endl;
	// int idxTemp = getAlphabetIdx(strWord[0]);
	// printVerticalScaledAlphabet(idxTemp);

    ofile.open("victory_korea_to_file.txt");
	cout << "=======================" << endl;
	for (int cnt = 0; cnt < strWord.size(); cnt++)
	{
		int idxCurrentAlphabet = getAlphabetIdx(strWord[cnt]);
		printVerticalScaledAlphabet(idxCurrentAlphabet);
		cout << endl;
		ofile << endl;
	}

	ofile.close();
	return 0;
}


	// for (int idx = 0; idx = 2; idx++)
	// {
	// 	char (*ppChar)[7] = chAlphabet[idx];
	// 	for (int i = 0; i < 7; i++) 
	// 	{
	// 		printf("%s\n", ppChar[i]);
	// 	}
	// }
	// char *pChar = chAlphabet[0][0];
	// char (*ppChar)[7] = chAlphabet[0];
	// printf("1. %s\n", ppChar[0]);
	// printf("%s\n", chAlphabet[0][0]);

	// cout << "string: " << strAlphabet[0][0] << endl;

	// // 세로로 출력하기
	// for (int i = 0; i < TOTAL_ALPHABET; i++)
	// {
	// 	cout << strAlphabet[i][0] << endl;
	// }
	// cout << endl;

	// for (int i = 0; i < HEIGHT_ALPHABET; i++)
	// {
	// 	cout << strAlphabet
	// }
